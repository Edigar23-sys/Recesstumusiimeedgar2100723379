name = "Hello Me"
print(name)
age = input("Enter Namfe")
print(name)
print(age)
print("the script from php.com from url. cilo")

#get print code
print('running python script')
print('i love python')


name = "Tumusiime Edgar"
school = "SCiT"
studentNo = 2100723379
print(studentNo, name, school)
